package ru.kazantsev.demo

class testModule2 {}