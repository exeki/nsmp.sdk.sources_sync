package ru.kazantsev.demo

class testModule1 {}