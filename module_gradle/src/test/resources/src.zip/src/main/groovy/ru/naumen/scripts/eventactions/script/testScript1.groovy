package ru.kazantsev.demo

class testScript1 {}